package EH.com.company;

import EH.com.company.IpConversionTools.IpConversionTools;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * @Author ErkHal
 *
 * Main for running the IPmachine.
 */

public class Main {

    public static void main(String[] args) {

        System.out.flush();

        boolean running = true;

        ArrayList<String> newIpResults = new ArrayList<>();

        Scanner scanner = new Scanner(System.in);

        String oldIp = "";

        System.out.println("\r\nPlease input the IP address with a prefix in format XXXXXXXX.XXXXXXXX.XXXXXXXX.XXXXXXXX/XX ");
        System.out.println(" To exit program, type exit.");

        while(running) {

            boolean gotCorrectInput = false;
            while (!gotCorrectInput) {

                oldIp = scanner.nextLine();
                if(!oldIp.equals("EXIT") && !oldIp.equals("exit")) {
                    newIpResults = IpConversionTools.calculateAddress(oldIp);
                } else {
                    System.exit(1);
                }

            if(newIpResults != null) {
                gotCorrectInput = true;
            }

        }
            //Retrieve original IP address in binary from results
            System.out.println("\r\nAddress :          " + oldIp + "   " + newIpResults.get(3));

            System.out.println("----------------------------------------------------------------------------------------");

            //Retrieve the decimal network address result, Binary network address result and address class from the results array.
             System.out.println("Network address:   " + newIpResults.get(0) + "     " + newIpResults.get(1) + "     " + newIpResults.get(2));


        }
    }
}
